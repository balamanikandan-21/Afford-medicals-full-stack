
# Stage 1

## Notification APIs

### GET Notifications
Endpoint:
`GET /api/v1/notifications?page=1&limit=10&type=Placement`

Headers:
```json
{
  "Authorization": "Bearer token"
}
```

Response:
```json
{
  "success": true,
  "notifications": [
    {
      "id": "uuid",
      "studentId": 1001,
      "notificationType": "Placement",
      "message": "Google Hiring",
      "isRead": false,
      "createdAt": "2026-04-22T17:51:18Z"
    }
  ]
}
```

### PATCH Mark Read
`PATCH /api/v1/notifications/:id/read`

### POST Send Notification
`POST /api/v1/notifications`

Request:
```json
{
  "studentIds": [1001,1002],
  "notificationType": "Placement",
  "message": "Amazon Hiring"
}
```

## Real Time Notification

Use Socket.IO with Redis Pub/Sub.

Advantages:
- Low latency
- Real-time updates
- Scalable multi-server communication

---

# Stage 2

## Database Choice

PostgreSQL recommended because:
- ACID compliance
- Better indexing
- Supports JSON if required
- Reliable joins and transactions

## Schema

```sql
CREATE TYPE notification_type AS ENUM (
'Placement',
'Result',
'Event'
);

CREATE TABLE students (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255),
  email VARCHAR(255) UNIQUE
);

CREATE TABLE notifications (
  id UUID PRIMARY KEY,
  student_id BIGINT REFERENCES students(id),
  notification_type notification_type,
  message TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);
```

## Scaling Issues

Problems:
- Full table scans
- Slow ordering
- High write load

Solutions:
- Composite indexes
- Read replicas
- Redis cache
- Table partitioning

---

# Stage 3

## Slow Query Analysis

Problem Query:
```sql
SELECT * FROM notifications
WHERE studentID = 1042 AND isRead = false
ORDER BY createdAt ASC;
```

Problems:
- SELECT * unnecessary
- Missing composite index
- Sorting expensive

Optimized Query:
```sql
SELECT id, message, notification_type, created_at
FROM notifications
WHERE student_id = 1042
AND is_read = false
ORDER BY created_at DESC
LIMIT 50;
```

Index:
```sql
CREATE INDEX idx_notifications_student_read_created
ON notifications(student_id, is_read, created_at DESC);
```

Why not indexes on every column?
- Slower inserts
- More storage
- Query planner overhead

Placement Query:
```sql
SELECT DISTINCT student_id
FROM notifications
WHERE notification_type='Placement'
AND created_at >= NOW() - INTERVAL '7 days';
```

---

# Stage 4

## Performance Improvements

### Redis Cache
Store unread notifications.

### Pagination
Load only required notifications.

### WebSockets
Avoid repeated polling.

### CDN + Compression
Improve frontend response speed.

Tradeoffs:
- Cache invalidation complexity
- Additional infrastructure cost

---

# Stage 5

## Problems

- Sequential execution
- Single point failure
- No retry mechanism

## Better Design

Use:
- Kafka/RabbitMQ
- Background workers
- Retry queues
- Dead letter queues

## Revised Pseudocode

```python
def notify_all(student_ids, message):
    for student_id in student_ids:
        queue.publish({
            "student_id": student_id,
            "message": message
        })

def worker(job):
    try:
        save_to_db(job)
        send_email(job)
        push_to_app(job)
    except:
        retry(job)
```

DB save and email should not be tightly coupled because external APIs fail independently.

---

# Stage 6

## Priority Inbox

Weights:
- Placement = 3
- Result = 2
- Event = 1

Priority Formula:
priority = weight + recency_score

Efficient Maintenance:
- Min Heap for Top 10
- O(log n)

