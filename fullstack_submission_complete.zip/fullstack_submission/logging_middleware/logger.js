
import axios from "axios";

const LOG_API = "http://4.224.186.213/evaluation-service/logs";

export async function Log(stack, level, pkg, message, token) {
  try {
    await axios.post(
      LOG_API,
      {
        stack,
        level,
        package: pkg,
        message
      },
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );
  } catch (error) {
    console.log("Log failed");
  }
}
