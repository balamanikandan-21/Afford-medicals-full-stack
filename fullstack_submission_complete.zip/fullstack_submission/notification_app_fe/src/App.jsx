
import { useEffect, useState } from "react";
import axios from "axios";

export default function App() {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    loadNotifications();
  }, []);

  async function loadNotifications() {
    const response = await axios.get(
      "http://localhost:5000/api/notifications"
    );

    setNotifications(response.data.notifications || []);
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Campus Notifications</h1>

      {notifications.map((notification) => (
        <div
          key={notification.ID}
          style={{
            border: "1px solid #ccc",
            marginBottom: 10,
            padding: 12,
            borderRadius: 8
          }}
        >
          <h3>{notification.Type}</h3>
          <p>{notification.Message}</p>
          <small>{notification.Timestamp}</small>
        </div>
      ))}
    </div>
  );
}
