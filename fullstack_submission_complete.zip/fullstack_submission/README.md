
# Campus Notification Platform

## Folder Structure

- logging_middleware
- notification_app_be
- notification_app_fe
- notification_system_design.md

## Backend Setup

```bash
cd notification_app_be
npm install
npm start
```

## Frontend Setup

```bash
cd notification_app_fe
npm install
npm run dev
```

Frontend runs on:
http://localhost:3000

Backend runs on:
http://localhost:5000
