
import express from "express";
import cors from "cors";
import axios from "axios";

const app = express();

app.use(cors());
app.use(express.json());

app.get("/api/notifications", async (req, res) => {
  try {
    const response = await axios.get(
      "http://4.224.186.213/evaluation-service/notifications"
    );

    res.json(response.data);
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch notifications"
    });
  }
});

app.listen(5000, () => {
  console.log("Backend running on port 5000");
});
