
const weights = {
  Placement: 3,
  Result: 2,
  Event: 1
};

function calculateScore(notification) {
  const age =
    (Date.now() - new Date(notification.Timestamp).getTime()) / 1000;

  return weights[notification.Type] * 100000 - age;
}

export function getTopNotifications(notifications) {
  return notifications
    .sort((a, b) => calculateScore(b) - calculateScore(a))
    .slice(0, 10);
}
